package codewithcal.au.calendarappexample;


import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class implementDelete extends AppCompatActivity {
    private ListView eventListView;
    Button btnDelete;
    ArrayAdapter myAdapter;

    private void initWidgets(){
        eventListView = findViewById(R.id.eventListView);
        btnDelete = findViewById(R.id.delete_item);
    }
    public static ArrayList<Event> eventsList = new ArrayList<>();

    public void OnCreate(Bundle saveIn){

    }
}
