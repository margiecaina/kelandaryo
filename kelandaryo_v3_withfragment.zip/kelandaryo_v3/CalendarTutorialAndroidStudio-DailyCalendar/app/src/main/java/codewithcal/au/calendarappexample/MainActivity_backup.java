

package codewithcal.au.calendarappexample;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import static codewithcal.au.calendarappexample.CalendarUtils.daysInMonthArray;
import static codewithcal.au.calendarappexample.CalendarUtils.daysInWeekArray;
import static codewithcal.au.calendarappexample.CalendarUtils.monthYearFromDate;
import static codewithcal.au.calendarappexample.CalendarUtils.selectedDate;
import static codewithcal.au.calendarappexample.Event.eventsList;

import com.google.android.material.navigation.NavigationView;

public class MainActivity_backup extends AppCompatActivity implements CalendarAdapter.OnItemListener
{
    ArrayList <Event> eventsListing = new ArrayList<Event>();

    private TextView monthYearText;
    private RecyclerView calendarRecyclerView;
    TextView btnMenu;
    private LocalTime time;
    String itemlisting;
    Integer indexValue;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initWidgets();
        CalendarUtils.selectedDate = LocalDate.now();
        setMonthView();
        //functionalities of navigational bar

        // adding the drawer navigational bar
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.menu_Open, R.string.close_menu);
        drawerLayout.addDrawerListener(actionBarDrawerToggle);

        actionBarDrawerToggle.syncState();

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override

            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch (item.getItemId()){
                    case R.id.nav_search:
                        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new searchFragment()).commit();
                        Log.i("MENU_DRAWER_TAG", "Search Item is clicked");
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case R.id.nav_special_occasion:
                        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new SpecialOccasionFragment()).commit();

                        Log.i("MENU_DRAWER_TAG", "Special Occasion Item is clicked");
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case R.id.nav_theme:
                        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new ThemeFragment()).commit();

                        Log.i("MENU_DRAWER_TAG", "Theme is clicked");
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                    case R.id.nav_about:
                        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new AboutFragment()).commit();

                        Log.i("MENU_DRAWER_TAG", "About Item is clicked");
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                }
                return false;
            }
        });

        //when list btn get click show navigational drawer
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.openDrawer(GravityCompat.START);
        drawer.closeDrawer(GravityCompat.START);
        btnMenu = (TextView) findViewById(R.id.drawer_layout);
        btnMenu.setOnClickListener(v -> {
            // TODO Auto-generated method stub
            if(drawer.isDrawerOpen(GravityCompat.START)){
                drawerLayout.closeDrawer(GravityCompat.START);
            }
            else {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        // implement hold to delete
        ArrayAdapter myAdapter;

        myAdapter = new ArrayAdapter<Event>(this, android.R.layout.activity_list_item, eventsListing);
        eventListView.setAdapter(myAdapter);
        LocalTime time;
        time = this.time;

        // given event
        Event newEvent = new Event("Activity 1", CalendarUtils.selectedDate, time);
        eventsList.add(newEvent);

        //clickable each event

        eventListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                itemlisting = adapterView.getItemAtPosition(i).toString() + " has been selected";
                indexValue = i;
                Toast.makeText(MainActivity_backup.this, itemlisting, Toast.LENGTH_SHORT).show();
            }
        });


        // delete event

        eventListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                itemlisting = adapterView.getItemAtPosition(i).toString() + " has been deleted";
                Toast.makeText(MainActivity_backup.this, itemlisting, Toast.LENGTH_SHORT).show();
                eventsList.remove(i);
                eventListView.setAdapter(myAdapter);
                myAdapter.notifyDataSetChanged();
                //to refresh the listview PLEASE DON'T DELETE
                setEventAdpater();
                return true;
            }

        });
    }

    private void initWidgets()
    {
        calendarRecyclerView = findViewById(R.id.calendarRecyclerView);
        monthYearText = findViewById(R.id.monthYearTV);
        eventListView = findViewById(R.id.eventListView);
    }

    @Override
    public void onItemClick(int position, LocalDate date)
    {
        CalendarUtils.selectedDate = date;
        setMonthView();
    }

    public void weeklyAction(View view)
    {
        startActivity(new Intent(this, WeekViewActivity.class));
    }

    //To see activity when added

    private ListView eventListView;

    private void setEventAdpater()
    {
        ArrayList<Event> dailyEvents = Event.eventsForDate(CalendarUtils.selectedDate);
        EventAdapter eventAdapter = new EventAdapter(getApplicationContext(), dailyEvents);
        eventListView.setAdapter(eventAdapter);
    }
    private void setMonthView()
    {
        monthYearText.setText(monthYearFromDate(CalendarUtils.selectedDate));
        ArrayList<LocalDate> daysInMonth = daysInMonthArray();

        CalendarAdapter calendarAdapter = new CalendarAdapter(daysInMonth, this);
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getApplicationContext(), 7);
        calendarRecyclerView.setLayoutManager(layoutManager);
        calendarRecyclerView.setAdapter(calendarAdapter);
        setEventAdpater();
    }

    private void setWeekView()
    {
        monthYearText.setText(monthYearFromDate(CalendarUtils.selectedDate));
        ArrayList<LocalDate> days = daysInWeekArray(CalendarUtils.selectedDate);

        CalendarAdapter calendarAdapter = new CalendarAdapter(days, this);
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getApplicationContext(), 7);
        calendarRecyclerView.setLayoutManager(layoutManager);
        calendarRecyclerView.setAdapter(calendarAdapter);
        setEventAdpater();
    }
    public void previousMonthAction(View view)
    {
        CalendarUtils.selectedDate = CalendarUtils.selectedDate.minusMonths(1);
        setMonthView();
    }

    public void nextMonthAction(View view)
    {
        CalendarUtils.selectedDate = CalendarUtils.selectedDate.plusMonths(1);
        setMonthView();
    }

    public void previousWeekAction(View view)
    {
        CalendarUtils.selectedDate = CalendarUtils.selectedDate.minusWeeks(1);
        setWeekView();
    }

    public void nextWeekAction(View view)
    {
        CalendarUtils.selectedDate = CalendarUtils.selectedDate.plusWeeks(1);
        setWeekView();
    }



    @Override
    protected void onResume()
    {
        super.onResume();
        setEventAdpater();
    }


    public void newEventAction(View view)
    {
        startActivity(new Intent(this, EventEditActivity.class));
    }

    public void dailyAction(View view)
    {
        startActivity(new Intent(this, DailyCalendarActivity.class));
    }

    // navigational declarations
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    Toolbar toolbar;
    ActionBarDrawerToggle actionBarDrawerToggle;
    @Override
    public void onBackPressed(){
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}










